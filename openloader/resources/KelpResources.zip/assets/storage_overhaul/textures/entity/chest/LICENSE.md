Textures in this directory are released under the Creative Commons BY-NC-SA 3.0 License.

They have been derived from [Quark][quark] to work with the Storage Overhaul mod.

### [Created by Vazkii and the Quark team][quark]
### [License](https://github.com/Vazkii/Quark/blob/master/LICENSE.md) ([Summary](https://creativecommons.org/licenses/by-nc-sa/3.0/))



[quark]: https://github.com/Vazkii/Quark
